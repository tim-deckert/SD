#ifndef __VOXGRID
#define __VOXGRID 2018

int voxelfilter(pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud,pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloudFiltered);

#endif
